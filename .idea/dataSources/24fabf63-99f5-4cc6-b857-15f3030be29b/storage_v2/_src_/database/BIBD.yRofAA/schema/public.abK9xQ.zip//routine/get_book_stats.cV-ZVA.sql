create function get_book_stats()
    returns TABLE(title character varying, author_name character varying, editions_count integer, min_price numeric, max_price numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT b.title, a.name, COUNT(*)::integer AS editions_count, MIN(b.price) AS min_price, MAX(b.price) AS max_price
    FROM books b
    JOIN books_authors ba ON b.id = ba.id_book
    JOIN authors a ON ba.id_author = a.id
    GROUP BY b.title, a.name
    HAVING COUNT(*) > 1;
END;
$$;

alter function get_book_stats() owner to postgres;

