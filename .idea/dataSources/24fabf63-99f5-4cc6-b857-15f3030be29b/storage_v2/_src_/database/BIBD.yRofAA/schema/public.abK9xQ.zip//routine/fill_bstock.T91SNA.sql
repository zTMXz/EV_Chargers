create function fill_bstock() returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO BStock (IDB, Quantity, price, DateCreate)
    SELECT b.id, 1, 10, CURRENT_DATE
    FROM top_books_last_month b;
END;
$$;

alter function fill_bstock() owner to postgres;

