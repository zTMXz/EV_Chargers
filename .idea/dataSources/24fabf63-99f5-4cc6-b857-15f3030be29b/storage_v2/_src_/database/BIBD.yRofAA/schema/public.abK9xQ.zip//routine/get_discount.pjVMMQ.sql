create function get_discount(quantity numeric) returns numeric
    language plpgsql
as
$$
BEGIN
    IF quantity IS NULL THEN
        RAISE EXCEPTION 'Quantity cannot be null or empty';
    END IF;

    IF quantity > 10 THEN
        RETURN 5;
    ELSIF quantity > 7 THEN
        RETURN 3;
    ELSIF quantity > 5 THEN
        RETURN 2;
    ELSIF quantity > 3 THEN
        RETURN 1;
    ELSE
        RETURN 0;
    END IF;
END;
$$;

alter function get_discount(numeric) owner to postgres;

