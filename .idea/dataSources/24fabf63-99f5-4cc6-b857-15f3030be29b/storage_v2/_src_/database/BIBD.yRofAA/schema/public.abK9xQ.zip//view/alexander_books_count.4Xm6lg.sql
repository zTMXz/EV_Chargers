create view alexander_books_count(cnt) as
SELECT count(b.title) AS cnt
FROM books_users_bought bub
         JOIN users u ON u.id = bub.id_user
         JOIN books b ON b.id = bub.id_book
WHERE u.login::text = 'Alexander'::text;

alter table alexander_books_count
    owner to postgres;

