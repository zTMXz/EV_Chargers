create function update_bstock() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT' OR TG_OP = 'UPDATE') THEN
        UPDATE BStock b SET Quantity = (SELECT COUNT(*) FROM books_users_bought ub WHERE ub.id_book = b.IDB )
                                                             -- AND DATE_TRUNC('month', ub.buy_date) = DATE_TRUNC('month', CURRENT_DATE))
         WHERE EXISTS (SELECT 1 FROM books_users_bought ub WHERE ub.id_book = b.IDB );
                                                             -- AND DATE_TRUNC('month', ub.buy_date) = DATE_TRUNC('month', CURRENT_DATE));
    ELSIF (TG_OP = 'DELETE') THEN
        UPDATE BStock b SET Quantity = Quantity - 1
        WHERE EXISTS (SELECT 1 FROM books_users_bought ub WHERE ub.id_book = b.IDB AND ub.id = OLD.id AND DATE_TRUNC('month', ub.buy_date) = DATE_TRUNC('month', CURRENT_DATE));
    END IF;
    RETURN NULL;
END;
$$;

alter function update_bstock() owner to postgres;

