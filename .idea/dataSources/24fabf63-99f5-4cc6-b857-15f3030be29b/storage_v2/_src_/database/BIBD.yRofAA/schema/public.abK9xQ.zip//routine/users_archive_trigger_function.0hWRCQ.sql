create function users_archive_trigger_function() returns trigger
    language plpgsql
as
$$
BEGIN
    IF TG_OP = 'UPDATE' THEN
        INSERT INTO users_archive (id, email, login, password, change_date)
        VALUES (OLD.id, OLD.email, OLD.login, OLD.password, NOW());
    END IF;
    RETURN NEW;
END;
$$;

alter function users_archive_trigger_function() owner to postgres;

