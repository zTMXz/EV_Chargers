create view top_books_last_month(id, title, num_purchases) as
SELECT b.id,
       b.title,
       count(*) AS num_purchases
FROM books_users_bought bub
         JOIN books b ON b.id = bub.id_book
WHERE bub.buy_date >= date_trunc('month'::text, CURRENT_DATE - '1 mon'::interval month)
  AND bub.buy_date < date_trunc('month'::text, CURRENT_DATE::timestamp with time zone)
GROUP BY b.id, b.title
ORDER BY (count(*)) DESC, b.title
LIMIT 10;

alter table top_books_last_month
    owner to postgres;

