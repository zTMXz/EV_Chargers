create function add_bumark(book_id integer, user_id integer, page integer, description character varying, create_date timestamp without time zone) returns void
    language plpgsql
as
$$
BEGIN
    IF book_id IS NULL THEN
        RAISE EXCEPTION 'Book ID cannot be null or empty';
    END IF;
    IF user_id IS NULL THEN
        RAISE EXCEPTION 'User ID cannot be null or empty';
    END IF;
    IF page IS NULL THEN
        RAISE EXCEPTION 'Page cannot be null or empty';
    END IF;
    IF description IS NULL OR description = '' THEN
        RAISE EXCEPTION 'Description cannot be null or empty';
    END IF;
    IF create_date IS NULL THEN
        RAISE EXCEPTION 'Create Date cannot be null or empty';
    END IF;

    INSERT INTO BUMark (IDB, IDU, Page, Description, DateCreate)
    VALUES (book_id, user_id, page, description, create_date);

END;
$$;

alter function add_bumark(integer, integer, integer, varchar, timestamp) owner to postgres;

