create function most_popular_first_purchase_book()
    returns TABLE(title character varying, first_purchase_date date, total_purchases integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT b.title, MIN(bub.buy_date::date) AS first_purchase_date, COUNT(*)::integer AS total_purchases
    FROM books b
    INNER JOIN books_users_bought bub ON b.id = bub.id_book
    GROUP BY b.id, buy_date
    ORDER BY total_purchases DESC, first_purchase_date
    LIMIT 1;
END;
$$;

alter function most_popular_first_purchase_book() owner to postgres;

